#pragma once
#include <Engine/OGLGame.h>
#include <string>
#include <vector>

#include "Enemy.h"
#include "Player.h"
#include "Bullet.h"
#include "Actor.h"
#include "Barrier.h"


struct GameFont;

/**
*  Invaders Game. An OpenGL Game based on ASGE.
*/
enum class GameState
{
	MAIN_MENU = 0,
	PLAYING = 1,
	GAME_OVER = 2,
	PAUSE = 3,
	EXIT = 4
};

class InvadersGame:
	public ASGE::OGLGame
{
public:
	InvadersGame();
	~InvadersGame();

	// Inherited via Game
	virtual bool run() override;
	bool shouldExit() const;
	void render();
	void initEnemyBulletSprite(int i);
	void initInvaderSprite();
	void initPlayerSprite();
	void initBulletSprite();
	void initBarrierSprite();
	// Inherited via OGLGame
	virtual bool init();
	virtual void drawFrame();
	void updateMenu();
	void updatePause();
	void collisionCheck();
	void setEnemyPace();
	void gameOver();
	void nextLevel();
	void checkBarrierHealth(int i);
	void bombDestroyEnemies(int i);
private:

	void processGameActions(); 
	void input(int key, int action) const;
	void destroyCollisionEnemy(int i);
	void destroyCollisionBullet();
	void destroyCollisionEnemyBullet(int i);
	const int NUM_OF_BARRIERS = 4;
	const int NUM_OF_ENEMIES = 55;
	const int NUM_OF_BULLETS = 2;
	int spacingX = 75;
	int spacingY = 100;
	int BspacingX = 150;
	int startFrame = 0;
	int startFrameEnemy = 0;
	int callback_id = -1;                             /**< Input Callback ID. The callback ID assigned by the game engine. */
	int enemy_pace = 60;
	int existing_Enemies = 55;
	bool exit = false;                                 /**< Exit boolean. If true the game loop will exit. */
	bool specialPowerActive = false;
	bool level_Reset = false;
	int bomb_sprite_frame = 0;
	//std::string scoreText = "0";
	//std::unique_ptr<ASGE::Sprite> sprite = nullptr;    /**< Sprite Object. The space invader sprite. */
	std::unique_ptr<Player> player = nullptr;
	std::unique_ptr<Bullet> bullet = nullptr;
	std::unique_ptr<Bullet> enemyBullet[2];
	std::vector<std::unique_ptr<ASGE::Sprite>> bombSprite;    /**< Sprite Object. The player sprite. */
	std::vector<std::unique_ptr<Barrier>> barriers;
	std::vector<std::unique_ptr<Enemy>> enemies;
};

