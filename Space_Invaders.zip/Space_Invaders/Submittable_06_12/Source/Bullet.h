#pragma once
#include <Engine/OGLGame.h>
#include <Engine/Sprite.h>
#include "Constants.h"
#include "Actor.h"
#include "Actions.h"

class Bullet : public Actor
{
	public:
		Bullet();
		~Bullet();
		std::unique_ptr<ASGE::Sprite> Bsprite = nullptr;    /**< Sprite Object. The bullet sprite. */
		
		void destroyBullet();
		void moveBullet();
		void moveEnemyBullet();
		float getPosX() const override;
		float getPosY() const override;
		float getWidth() const override;
		float getHeight() const override;
		bool getIsAlive() override;
	private:
		bool isAlive = true;

};