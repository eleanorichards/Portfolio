#include "Game.h"
#include "Actions.h"
#include "Constants.h"
#include "GameFont.h"

#include <Engine/Input.h>
#include <Engine/Keys.h>
#include <Engine/Sprite.h>

std::atomic<GameState> game_state = GameState::MAIN_MENU;

/**
*   @brief   Default Constructor.
*/
InvadersGame::InvadersGame()
{
}



/**
*   @brief   Destructor.
*   @details Remove any non-managed memory and callbacks.
*/
InvadersGame::~InvadersGame()
{
	this->inputs->unregisterCallback(callback_id);
	for (auto& font : GameFont::fonts)
	{
		delete font;
		font = nullptr;
	}
}



/**
*   @brief   Initialises the game.
*   @details The game window is created and all assets required to
			 run the game are loaded. The input callback should also
			 be set in the initialise function. 
*   @return  True if the game initialised correctly.
*/
bool InvadersGame::init()
{
	width = WINDOW_WIDTH;
	height = WINDOW_HEIGHT;
	if (!initAPI())
	{
		return false;
	}

	renderer->setWindowTitle("Space Invaders");
	renderer->setClearColour(ASGE::COLOURS::BLACK);
	toggleFPS();

	// input callback function
	callback_id = this->inputs->addCallbackFnc(&InvadersGame::input, this);

	// load fonts we need
	GameFont::fonts[0] = new GameFont(
		renderer->loadFont("..\\..\\Resources\\Fonts\\Comic.ttf", 42), "default", 42);

	if (GameFont::fonts[0]->id == -1)
	{
		return false;
	}

	//initialise bomb sprite (bottom left corner)
	for (int i = 0; i < 2; i++)
	{
		bombSprite.push_back(renderer->createSprite());
	}

	bombSprite[0]->loadTexture("..\\..\\Resources\\Textures\\bombRed.png");
	bombSprite[1]->loadTexture("..\\..\\Resources\\Textures\\bomb.png");

	for (int i = 0; i < 2; i++)
	{
		bombSprite[i]->scale = 0.2;
		bombSprite[i]->position[0] = 10;
		bombSprite[i]->position[1] = WINDOW_HEIGHT - 100;
	}


	//load in enemy invader sprites
	enemies.reserve(55);
	initInvaderSprite();


	//load in player sprite
	initPlayerSprite();
	if (!player->Psprite->loadTexture("..\\..\\Resources\\Textures\\Player.png"))
	{
		return false;
	}


	//load in barrier sprites
	barriers.reserve(4);
	initBarrierSprite();
	for (int i = 0; i < NUM_OF_BARRIERS; i++)
	{
		if (!barriers[i]->Basprite->loadTexture("..\\..\\Resources\\Textures\\Barrier.png"))
		{
			return false;
		}
	}

	//make first initialisation of enemy bullet
	for (int i = 0; i < NUM_OF_BULLETS; i++)
	{
		initEnemyBulletSprite(i);
	}
}



/**
*   @brief   The main game loop.
*   @details The main loop should be responsible for updating the game
			 and rendering the current scene. Runs until the shouldExit
			 signal is received.
*   @return  True if the game ran correctly.
*/
bool InvadersGame::run()
{
	while (!shouldExit())
	{
		if (game_state == GameState::PLAYING)
		{
			startFrame++;
			if (startFrame >= enemy_pace)
			{
				for (int i = 0; i < NUM_OF_ENEMIES; i++)
				{
					//check each enemy's relative positioning on screen
					if (enemies[i]->getIsAlive())
					{
						enemies[i]->checkEnemyState();
					}
				}

				setEnemyPace();
				startFrame = 0;

				for (int i = 0; i < NUM_OF_ENEMIES; i++)
				{
					//move each enemy
					enemies[i]->processMovement();
					if (enemies[i]->SIsprite->position[1] >= WINDOW_HEIGHT - 100)
					{
						game_state = GameState::GAME_OVER;
					}
				}
			}
			//change bomb sprite texture depending on state
			if (!player->canUseSpecialBullet())
			{
				bomb_sprite_frame = 0;
			}
			else if(player->canUseSpecialBullet())
			{
				bomb_sprite_frame = 1;
			}
			render();
			collisionCheck();
			if (existing_Enemies <= 0)
			{
				nextLevel();
			}
		}
		processGameActions();
	}
	return true;
}



/**
*   @brief   Should the game exit?
*   @details Has the renderer terminated or the game requesting to exit?
*   @return  True if the game should exit
*/
bool InvadersGame::shouldExit() const
{
	return (renderer->exit() || this->exit);
}



/**
*   @brief   Renders the scene
*   @details Prepares the renderer subsystem before drawing the
			 current frame. Once the current frame is has finished
			 the buffers are swapped accordingly and the image shown.
*   @return  void
*/
void InvadersGame::render()
{
	beginFrame();
	drawFrame();
	endFrame();
}



void InvadersGame::initEnemyBulletSprite(int i)
{
	enemyBullet[i] = std::make_unique<Bullet>();
	enemyBullet[i]->Bsprite = renderer->createSprite();

	if (!enemyBullet[i]->Bsprite->loadTexture("..\\..\\Resources\\Textures\\Bullet.png"))
	{
		return;
	}
	int x = rand() % 55;
	if (enemies[x] && enemies[x]->getIsAlive())
	{	
		enemyBullet[i]->Bsprite->position[0] = enemies[x]->getPosX();
		enemyBullet[i]->Bsprite->position[1] = enemies[x]->getPosY();
		enemyBullet[i]->Bsprite->scale = 4;
	}
}



void InvadersGame::initInvaderSprite()
{
	// load space invader sprites
	for (int i = 0; i < NUM_OF_ENEMIES; i++)
	{	
		if (!level_Reset)
		{
			enemies.push_back(std::make_unique<Enemy>());
			enemies[i]->SIsprite = renderer->createSprite();
		}
		level_Reset = false;
		enemies[i]->SIsprite->scale = 3;		
		enemies[i]->setAlive();
		//set spacing for each sprite
		if (i % 11 == 0 && i !=0)
		{
			spacingX = 75;
			spacingY += 50;
		}
		enemies[i]->SIsprite->position[0] = spacingX;
		enemies[i]->SIsprite->position[1] = spacingY;
		spacingX += 75;
	}
	//load in diferent texture for each row of enemies
	for (int i = 0; i < NUM_OF_ENEMIES; i++)
	{
		if (i < 11)
		{
			if (!enemies[i]->SIsprite->loadTexture("..\\..\\Resources\\Textures\\Top_Alien_1.png"))
			{
				return;
			}
		}
		else if (i < 22)
		{
			if (!enemies[i]->SIsprite->loadTexture("..\\..\\Resources\\Textures\\Top_Alien_2.png"))
			{
				return;
			}
		}
		else if (i < 33)
		{
			if (!enemies[i]->SIsprite->loadTexture("..\\..\\Resources\\Textures\\Mid_Alien_2.png"))
			{
				return;
			}
		}
		else if (i < 44)
		{
			if (!enemies[i]->SIsprite->loadTexture("..\\..\\Resources\\Textures\\Mid_Alien_1.png"))
			{
				return;
			}
		}
		else if (i <= 55)
		{
			if (!enemies[i]->SIsprite->loadTexture("..\\..\\Resources\\Textures\\Bot_Alien_1.png"))
			{
				return;
			}
		}

	}
}



void InvadersGame::checkBarrierHealth(int i)
{
	
	if (barriers[i]->getHealth() == 15)
	{
		if (!barriers[i]->Basprite->loadTexture("..\\..\\Resources\\Textures\\Barrier.png"))
		{
			return;
		}
	}
	else if (barriers[i]->getHealth() == 12)
	{
		if (!barriers[i]->Basprite->loadTexture("..\\..\\Resources\\Textures\\Barrier2.png"))
		{
			return;
		}
	}
	else if (barriers[i]->getHealth() == 9)
	{
		if (!barriers[i]->Basprite->loadTexture("..\\..\\Resources\\Textures\\Barrier3.png"))
		{
			return;
		}
	}
	else if (barriers[i]->getHealth() == 6)
	{
		if (!barriers[i]->Basprite->loadTexture("..\\..\\Resources\\Textures\\Barrier4.png"))
		{
			return;
		}
	}
	else if (barriers[i]->getHealth() == 3)
	{
		if (!barriers[i]->Basprite->loadTexture("..\\..\\Resources\\Textures\\Barrier5.png"))
		{
			return;
		}
	}
}


//initialise player sprite at centre of screen
void InvadersGame::initPlayerSprite()
{
	player = std::make_unique<Player>();
	player->Psprite = renderer->createSprite();
	player->Psprite->position[0] = WINDOW_WIDTH/2;
	player->Psprite->position[1] = WINDOW_HEIGHT - 80;
	player->Psprite->scale = 3;
}



void InvadersGame::initBulletSprite()
{
	bullet = std::make_unique<Bullet>();
	bullet->Bsprite = renderer->createSprite();
	if (!bullet->Bsprite->loadTexture("..\\..\\Resources\\Textures\\Bullet.png"))
	{
		return;
	}
	if (bullet_state == BulletState::PLAYER_FIRE || bullet_state == BulletState::PLAYER_SPECIAL_FIRE)
	{
		//set bullet position to current player pos
		bullet->Bsprite->position[0] = player->getPosX() + 20;
		bullet->Bsprite->position[1] = player->getPosY();
		bullet->Bsprite->scale = 4;
	}
	
}



void InvadersGame::initBarrierSprite()
{
	for (int i = 0; i < NUM_OF_BARRIERS; i++)
	{
		barriers.push_back(std::make_unique<Barrier>());
		barriers[i]->Basprite = renderer->createSprite();

		barriers[i]->Basprite->position[0] = BspacingX;
		barriers[i]->Basprite->position[1] = 500;
		barriers[i]->Basprite->scale = 4;
		BspacingX += 300;
	}
}



/**
*   @brief   Renderers the contents for this frame 
*   @details All game objects that need rendering should be done
			 in this function, as it ensures they are completed
			 before the buffers are swapped.
*   @return  void
*/
void InvadersGame::drawFrame()
{
	renderer->setFont(GameFont::fonts[0]->id);
	//draw bomb sprite depending on state
	bombSprite[bomb_sprite_frame]->render(renderer);
	//draw enemies
	for (int i = 0; i < NUM_OF_ENEMIES; i++)
	{
		if (enemies[i] && enemies[i]->getIsAlive())
		{
			enemies[i]->SIsprite->render(renderer);
		}
	}
	//draw barriers
	for (int i = 0; i < NUM_OF_BARRIERS; i++)
	{
		if (barriers[i]->getIsAlive())
		{
			barriers[i]->Basprite->render(renderer);
		}
	}
	//draw player
	player->Psprite->render(renderer);

	if (bullet_state == BulletState::PLAYER_FIRE || bullet_state == BulletState::PLAYER_SPECIAL_FIRE)
	{
		bullet->Bsprite->render(renderer);
	}
	//draw bullets
	for (int i = 0; i < NUM_OF_BULLETS; i++)
	{
		if (enemyBullet[i] && enemyBullet[i]->getIsAlive())
		{			
			enemyBullet[i]->Bsprite->render(renderer);
			enemyBullet[i]->moveEnemyBullet();
		}
	}
	//display score
	std::string score = std::to_string(player->getScore());
	renderer->setFont(GameFont::fonts[0]->id);
	std::string tmp = "Score: ";
	tmp.append(score);
	renderer->renderText(tmp.c_str(), 10, 30, 1.0, ASGE::COLOURS::MEDIUMSEAGREEN);

	//display level
	std::string level = std::to_string(player->getLevel());
	renderer->setFont(GameFont::fonts[0]->id);
	std::string tmp3 = "Level: ";
	tmp3.append(level);
	renderer->renderText(tmp3.c_str(), 550, 30, 1.0, ASGE::COLOURS::FORESTGREEN);

	//display lives
	std::string lives = std::to_string(player->getLives());
	renderer->setFont(GameFont::fonts[0]->id);
	std::string tmp2 = "Lives: ";
	tmp2.append(lives);
	renderer->renderText(tmp2.c_str(), 1100, 30, 1.0, ASGE::COLOURS::DARKGREEN);
}



void InvadersGame::updateMenu()
{
	beginFrame();
	renderer->setFont(GameFont::fonts[0]->id);

	renderer->renderText("SPACE INVADERS", 10, 30, 1.0, ASGE::COLOURS::FORESTGREEN);

	renderer->renderText("Are you ready?. \nPress any key to begin", 300, 300, ASGE::COLOURS::DARKGREEN);

	endFrame();
}



void InvadersGame::updatePause()
{
	beginFrame();
	renderer->setFont(GameFont::fonts[0]->id);

	renderer->renderText("SPACE INVADERS", 10, 30, 1.0, ASGE::COLOURS::FORESTGREEN);

	renderer->renderText("Paused \nPress enter to continue", 200, 200, ASGE::COLOURS::DARKGREEN);

	endFrame();
}



void InvadersGame::gameOver()
{	
	std::string score = std::to_string(player->getScore());
	std::string tmp4 = "	GAME OVER! \nYour score was: ";
	tmp4.append(score);
	beginFrame();
	renderer->setFont(GameFont::fonts[0]->id);

	renderer->renderText("SPACE INVADERS", 5, 30, 1.0, ASGE::COLOURS::MEDIUMSEAGREEN);

	renderer->renderText(tmp4.c_str(), 300, 300, ASGE::COLOURS::FORESTGREEN);

	renderer->renderText("Press any key to exit...", (WINDOW_WIDTH - 480), (WINDOW_HEIGHT - 5), 1.0, ASGE::COLOURS::DARKGREEN);
	endFrame();
}



void InvadersGame::collisionCheck()
{
	if (bullet)
	{
		if (bullet->Bsprite->position[1] <= 10 || bullet->Bsprite->position[1] >= WINDOW_HEIGHT)
		{
			//if bullet reaches edge of screen, destroy
			destroyCollisionBullet();
		}
	}
	
	for (int i = 0; i < NUM_OF_ENEMIES; i++)
	{
		if (bullet && bullet->hasCollided(*bullet, *enemies[i]))
		{
			//DESTROY BULLET, DESTROY ENEMY IF COLLIDED
			destroyCollisionBullet();
			destroyCollisionEnemy(i);
			
		}		
	}
	for (int x = 0; x < NUM_OF_BULLETS; x++)
	{
		if (enemyBullet[x])
		{
			if (enemyBullet[x]->Bsprite->position[1] <= 10 || enemyBullet[x]->Bsprite->position[1] >= WINDOW_HEIGHT)
			{
				//DESTROY BULLET ON EDGE OF SCREEN
				destroyCollisionEnemyBullet(x);
			}
		}
		if (enemyBullet[x] && enemyBullet[x]->hasCollided(*player, *enemyBullet[x]))
		{
			//DAMAGE PLAYER, DESTROY BULLET IF COLLIDED
			destroyCollisionEnemyBullet(x);
			player->damagePlayer();
			if (!player->getIsAlive())
			{
				game_state = GameState::GAME_OVER;
			}
		}
	}
	for (int i = 0; i < NUM_OF_BARRIERS; i++)
	{
		for (int x = 0; x < NUM_OF_BULLETS; x++)
		{
			if (bullet && bullet->hasCollided(*bullet, *barriers[i]))
			{
				//DESTROY PLAYER BULLET, DAMAGE BARRIER IF COLLIDED
				destroyCollisionBullet();
				barriers[i]->damageBarrier();
				checkBarrierHealth(i);
			}
			if (enemyBullet[x] && enemyBullet[x]->hasCollided(*enemyBullet[x], *barriers[i]))
			{
				//DESTROY ENEMY BULLET, DAMAGE BARRIER IF COLLIDED
				destroyCollisionEnemyBullet(x);
				barriers[i]->damageBarrier();
				checkBarrierHealth(i);

			}
		}
	}
}



void InvadersGame::setEnemyPace()
{
	//switch is level number, enemy speeds are adjusted accordingly
	switch (player->getLevel())
	{
	case 1:
		if (existing_Enemies >= 36)
		{
			enemy_pace = 60;
		}
		else if (existing_Enemies >= 27)
		{
			enemy_pace = 50;
		}
		else if (existing_Enemies >= 18)
		{
			enemy_pace = 40;
		}
		else if (existing_Enemies >= 9)
		{
			enemy_pace = 30;
		}
		else if (existing_Enemies >= 0)
		{
			enemy_pace = 20;
		}
		break;
	case 2:
		if (existing_Enemies >= 36)
		{
			enemy_pace = 50;
		}
		else if (existing_Enemies >= 27)
		{
			enemy_pace = 40;
		}
		else if (existing_Enemies >= 18)
		{
			enemy_pace = 30;
		}
		else if (existing_Enemies >= 9)
		{
			enemy_pace = 20;
		}
		else if (existing_Enemies >= 0)
		{
			enemy_pace = 10;
		}
		break;
	case 3:
		if (existing_Enemies >= 36)
		{
			enemy_pace = 40;
		}
		else if (existing_Enemies >= 27)
		{
			enemy_pace = 30;
		}
		else if (existing_Enemies >= 18)
		{
			enemy_pace = 20;
		}
		else if (existing_Enemies >= 9)
		{
			enemy_pace = 10;
		}
		else if (existing_Enemies >= 0)
		{
			enemy_pace = 5;
		}
		break;
	}
	
}



void InvadersGame::nextLevel()
{
	//progress to next level, re-init
	player->levelUp();
	existing_Enemies = 55;
	spacingX = 75;
	spacingY = 100;
	level_Reset = true;
	initInvaderSprite();
	for (int i = 0; i < NUM_OF_BULLETS; i++)
	{
		initEnemyBulletSprite(i);
	}
}





/**
*   @brief   Processes any key inputs and translates them to a GameAction
*   @details This function is added as a callback to handle the game's 
			 input. Key presseses are translated in to GameActions which 
			 are then processed by the main game loop.
*   @param   key is the key the action relates to
*   @param   action whether the key was released or pressed
*   @return  void
*/
void InvadersGame::input(int key, int action) const
{
	//press any key to exit main menu
	if (action == ASGE::KEYS::KEY_PRESSED && game_state == GameState::MAIN_MENU)
	{
		game_state = GameState::PLAYING;
	}

	//check keyPress during play
	if (game_state == GameState::PLAYING)
	{
		if (key == ASGE::KEYS::KEY_ESCAPE)
		{
			game_state = GameState::EXIT;
		}
		if (key == ASGE::KEYS::KEY_P)
		{
			game_state = GameState::PAUSE;
		}
	}
	//if enter is pressed during pause, continue game
	if (game_state == GameState::PAUSE)
	{
		if (key == ASGE::KEYS::KEY_ENTER)
		{
			game_state = GameState::PLAYING;
		}
	}

	if (game_state == GameState::GAME_OVER)
	{
		if (action == ASGE::KEYS::KEY_PRESSED)
		{
			game_state = GameState::EXIT;
		}
	}
	
	//player controls
	if (key == ASGE::KEYS::KEY_A)
	{
		player_Movement = PlayerMovement::LEFT;
		player->movePlayer();
	}
	if (key == ASGE::KEYS::KEY_D)
	{
		player_Movement = PlayerMovement::RIGHT;
		player->movePlayer();
	}
	if (key == ASGE::KEYS::KEY_SPACE)
	{
		bullet_state = BulletState::PLAYER_FIRE;
	}
	//special bomb
	if (key == ASGE::KEYS::KEY_E)
	{
		if (player->canUseSpecialBullet())
		{
			bullet_state = BulletState::PLAYER_SPECIAL_FIRE;
		}
	}
}



void InvadersGame::destroyCollisionEnemy(int i)
{
	player->updateScore(i);
	existing_Enemies--;		
	enemies[i]->destroyEnemy();
	//enemies[i] = nullptr;
	//if the special power is active. BOMB
	if (specialPowerActive)
	{
		int new_i = i;
		int scoreI = 100;
		player->updateScore(scoreI);
		specialPowerActive = false;

		new_i = i + 11;
		bombDestroyEnemies(new_i);//down

		new_i = i - 11;
		bombDestroyEnemies(new_i);//up

		new_i = i + 1;
		bombDestroyEnemies(new_i);//right

		new_i = i - 1;
		bombDestroyEnemies(new_i);//left

		new_i = i - 12;
		bombDestroyEnemies(new_i);//up_left

		new_i = i + 12;
		bombDestroyEnemies(new_i);//up_right

		new_i = i - 10;
		bombDestroyEnemies(new_i);//down_left

		new_i = i + 10;
		bombDestroyEnemies(new_i);//down_right
	}
}



void InvadersGame::bombDestroyEnemies(int i)
{
	//destroy adjacent enemies if they exist
	if (i < 55 && i > 0 && ((i + 1) %  11 !=  0) && ((i - 1) % 11 != 0))
	{ 
		if (enemies[i] && enemies[i]->getIsAlive())
		{
			existing_Enemies--;
			enemies[i]->destroyEnemy();
		}
	}
}


//destroy bullet on collision
void InvadersGame::destroyCollisionBullet()
{
	bullet->destroyBullet();
	bullet = nullptr;
	bullet_state = BulletState::NONE;
}


//destroy enemy bullet on collision
void InvadersGame::destroyCollisionEnemyBullet(int i)
{
	enemyBullet[i]->destroyBullet();
	initEnemyBulletSprite(i);
}



/**
*   @brief   Processes the next game action
*   @details Uses the game action that was a direct result of 
*            user input. It allows input to processed in a different
             thread and the game actions performed in the main thread. 
*   @return  void
*/
void InvadersGame::processGameActions()
{
	if (game_state == GameState::EXIT)
	{
		this->exit = true;
	}
	if (game_state == GameState::MAIN_MENU)
	{	
		updateMenu();
	}
	if (game_state == GameState::PAUSE)
	{
		updatePause();
	}
	if (game_state == GameState::PLAYING)
	{
		//if PLAYING process game
		if (bullet_state == BulletState::PLAYER_FIRE || bullet_state == BulletState::PLAYER_SPECIAL_FIRE)
		{
			if (bullet_state == BulletState::PLAYER_SPECIAL_FIRE)
			{
				specialPowerActive = true;
			}
			if (!bullet)
			{
				initBulletSprite();
			}
			bullet->moveBullet();
		}
		
	}

	if (game_state == GameState::GAME_OVER)
	{
		gameOver();
	}
	for (int i = 0; i < NUM_OF_BULLETS; i++)
	{
		if (enemyBullet[i] && !enemyBullet[i]->getIsAlive())
		{
			initEnemyBulletSprite(i);
		}
	}
	game_action = GameAction::NONE;
}