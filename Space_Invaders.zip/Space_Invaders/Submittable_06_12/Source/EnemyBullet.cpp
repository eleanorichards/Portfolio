#include "EnemyBullet.h"

EnemyBullet::EnemyBullet()
{
}

EnemyBullet::~EnemyBullet()
{
}

void EnemyBullet::moveBullet()
{
}

float EnemyBullet::getPosX() const
{
	return enemyBsprite->position[0];
}

float EnemyBullet::getPosY() const
{
	return enemyBsprite->position[1];
}

float EnemyBullet::getWidth() const
{
	return 10;
}

float EnemyBullet::getHeight() const
{
	return 10;
}

bool EnemyBullet::getIsAlive()
{
	return isAlive;
}

void EnemyBullet::destroyBullet()
{
	isAlive = false;
}
