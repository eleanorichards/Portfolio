#include "Player.h"
#include "Constants.h"
//player movement
//bullet class (Has-A) 
//death = isAlive

Player::Player()
{
}

Player::~Player()
{
}



void Player::movePlayer()
{
	if (player_Movement == PlayerMovement::LEFT)
	{
		Psprite->position[0] -= 10;
	}
	if (player_Movement == PlayerMovement::RIGHT)
	{
		Psprite->position[0] += 10;
	}
}



void Player::updateScore(int i)
{
	//update score depending on what row of enemy was hit
	if (i < 11)
		score += 50;
	else if (i < 22)
		score += 40;
	else if (i < 33)
		score += 30;
	else if (i < 44)
		score += 30;
	else if (i < 55)
		score += 10;
	else if (i == 100)
	{
		score -= 200;
	}
}



void Player::levelUp()
{
	level++;
}



float Player::getPosX() const
{
	return Psprite->position[0];
}



float Player::getPosY() const
{
	return Psprite->position[1];
}



float Player::getWidth() const
{
	return 30;
}



float Player::getHeight() const
{
	return 15;
}



bool Player::getIsAlive()
{
	return isAlive;
}


//return true if score is above 200
bool Player::canUseSpecialBullet()
{
	if (score >= 200)
	{
		return true;
	}
	else
	{
		return false;
	}
}



void Player::damagePlayer()
{
	lives--;
	if (lives <= 0)
	{
		isAlive = false;
	}
	Psprite->position[0] = (WINDOW_WIDTH / 2);
}



int Player::getLives()
{
	return lives;
}



int Player::getScore()
{
	return score;
}



int Player::getLevel()
{
	return level;
}


