#include "Barrier.h"

Barrier::Barrier()
{
}

Barrier::~Barrier()
{
}



float Barrier::getPosX() const
{
	return Basprite->position[0] + 5;
}



float Barrier::getPosY() const
{
	return Basprite->position[1];
}



float Barrier::getWidth() const
{
	return 75;
}



float Barrier::getHeight() const
{
	return 50;
}



int Barrier::damageBarrier()
{
	lifeLeft--;
	if (lifeLeft <= 0)
	{
		isAlive = false;
	}
	return lifeLeft;
}



int Barrier::getHealth()
{
	return lifeLeft;
}



bool Barrier::getIsAlive()
{
	return isAlive;
}
