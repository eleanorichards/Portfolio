#include "Bullet.h"



Bullet::Bullet()
{
}



Bullet::~Bullet()
{
}


//move bullet up y axis
void Bullet::moveBullet()
{
	Bsprite->position[1] -= 13;
}


//move enemy bullet down y axis
void Bullet::moveEnemyBullet()
{
	Bsprite->position[1] += 7;
}



float Bullet::getPosX() const
{
	return Bsprite->position[0];
}



float Bullet::getPosY() const
{
	return Bsprite->position[1];
}



float Bullet::getWidth() const
{
	return 20;
}



float Bullet::getHeight() const
{
	return 10;
}



bool Bullet::getIsAlive()
{
	return isAlive;
}



void Bullet::destroyBullet()
{
	isAlive = false;
	//Bsprite = nullptr;
}
