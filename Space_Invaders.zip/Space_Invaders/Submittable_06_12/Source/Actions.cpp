#include "Actions.h"

/**< Queued Game Action. The next action to be processed as determined by user input. */
std::atomic<GameAction> game_action = GameAction::NONE;
std::atomic<PlayerMovement> player_Movement = PlayerMovement::NONE;
std::atomic<EnemyMovement> enemy_Movement = EnemyMovement::LEFT;
std::atomic<BulletState> bullet_state = BulletState::NONE;

