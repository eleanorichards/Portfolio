#pragma once
#include "Timer.h"

void Timer::startTimer()
{
	start_time = time::now();
}

float Timer::returnDelay()
{
	return ((time::now() - start_time).count()) * 0.0000000001;
}
