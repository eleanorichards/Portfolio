#pragma once
#include <Engine/OGLGame.h>
#include <Engine/Sprite.h>
#include "Actions.h"
#include "Actor.h"
//to use for the space invaders
class Enemy : public Actor
{
public:
	Enemy();
	~Enemy();

	std::unique_ptr<ASGE::Sprite> SIsprite = nullptr;    /**< Sprite Object. The space invader sprite. */
	void checkEnemyState();
	void processMovement();
	void setAlive();
	float getPosX() const override;
	float getPosY() const override;
	float getWidth() const override;
	float getHeight() const override;
	bool getIsAlive() override;
	void destroyEnemy();

private:
	bool isAlive = true;
	bool goneDown = false;
	bool move_left = false;
	bool move_right = false;
	

};