#pragma once
#include <Engine/OGLGame.h>
#include <Engine/Sprite.h>
#include "Constants.h"
#include "Actor.h"
#include "Actions.h"

class EnemyBullet : public Actor
{
public:
	EnemyBullet();
	~EnemyBullet();
	std::unique_ptr<ASGE::Sprite> enemyBsprite = nullptr;    /**< Sprite Object. The bullet sprite. */
														//std::unique_ptr<ASGE::Sprite> enemyBsprite = nullptr;
	void moveBullet();
	float getPosX() const override;
	float getPosY() const override;
	float getWidth() const override;
	float getHeight() const override;
	bool getIsAlive() override;
	void destroyBullet();
private:
	bool isAlive = true;
};