#pragma once
#include <Engine/OGLGame.h>
#include <Engine/Sprite.h>
#include "Actions.h"
#include "Actor.h"

class Player : public Actor
{
public:

	Player();
	~Player();
	std::unique_ptr<ASGE::Sprite> Psprite = nullptr;    /**< Sprite Object. The player sprite. */

	float getPosX() const override;
	float getPosY() const override;
	float getWidth() const override;
	float getHeight() const override;
	bool getIsAlive() override;
	bool canUseSpecialBullet();
	void damagePlayer();
	void movePlayer();
	void updateScore(int i);
	void levelUp();
	int getLives();
	int getScore();
	int getLevel();

protected:
	bool isAlive = true;
	int score = 0;
	int lives = 3;
	int level = 1;
};