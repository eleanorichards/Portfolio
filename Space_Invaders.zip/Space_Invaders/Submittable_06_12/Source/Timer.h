#pragma once
#include <chrono>

class Timer
{
public:
	void startTimer();
	float returnDelay();

private:
	using time = std::chrono::high_resolution_clock;
	using steady_clock = std::chrono::time_point < std::chrono::steady_clock>;

	steady_clock start_time;
};