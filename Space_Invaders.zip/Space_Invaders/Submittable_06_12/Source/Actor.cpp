#include "Actor.h"



bool Actor::hasCollided(Actor& b, Actor& a)
{
	if (a.getIsAlive() && b.getIsAlive())
	{
		if ((a.getPosX() + a.getWidth()) >= (b.getPosX()) &&
			(a.getPosX()) <= (b.getPosX() + b.getWidth()) &&
			(a.getPosY() + a.getHeight()) >= (b.getPosY()) &&
			(a.getPosY()) <= (b.getPosY() + b.getHeight()))
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}
}



float Actor::getPosX() const
{
	return posX;
}



float Actor::getPosY() const
{
	return posY;
}



bool Actor::getIsAlive()
{
	return isAlive;
}