#pragma once

class Actor 
{
public:

	bool hasCollided(Actor& b, Actor& a);
	virtual float getPosX() const;
	virtual float getPosY() const;
	virtual float getWidth() const = 0;
	virtual float getHeight() const = 0;
	virtual bool getIsAlive();

private:
	bool isAlive;
	float width;
	float height;
	float posX;
	float posY;

};