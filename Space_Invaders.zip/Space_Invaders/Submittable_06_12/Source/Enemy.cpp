#include "Enemy.h"
#include "Constants.h"


Enemy::Enemy()
{
	
}

Enemy::~Enemy()
{
}


//check enemy state, move down once if edge reached, then opposite direction
void Enemy::checkEnemyState()
{
	if (move_left && goneDown)
	{
		enemy_Movement = EnemyMovement::LEFT;
		move_left = false;
		goneDown = false;
		return;
	}
	else if (move_right && goneDown)
	{
		enemy_Movement = EnemyMovement::RIGHT;
		move_right = false;
		goneDown = false;
		return;
	}



	if ((SIsprite) && SIsprite->position[0] >= WINDOW_WIDTH - 50)
	{
		enemy_Movement = EnemyMovement::DOWN;
		move_left = true;
		return;
	}
	else if ((SIsprite) && SIsprite->position[0] <= 20)
	{
		enemy_Movement = EnemyMovement::DOWN;
		move_right = true;
		return;
	}
}

void Enemy::processMovement()
{
	//move enemy depending on state
	if (enemy_Movement == EnemyMovement::LEFT)
	{
		SIsprite->position[0] -= 30;
	}
	if (enemy_Movement == EnemyMovement::RIGHT)
	{
		SIsprite->position[0] += 30;
	}
	if (enemy_Movement == EnemyMovement::DOWN)
	{
		SIsprite->position[1] += 30;
		goneDown = true;
	}
	if (enemy_Movement == EnemyMovement::UP)
	{
		SIsprite->position[1] -= 30;
	}
	
}



void Enemy::setAlive()
{
	isAlive = true;
}



float Enemy::getPosX() const
{
	return SIsprite->position[0] + 15;
}



float Enemy::getPosY() const
{
	return SIsprite->position[1];
}



float Enemy::getWidth() const
{
	return 15;
}



float Enemy::getHeight() const
{
	return 15;
}



bool Enemy::getIsAlive()
{
	return isAlive;
}



void Enemy::destroyEnemy()
{
	isAlive = false;
	
}


