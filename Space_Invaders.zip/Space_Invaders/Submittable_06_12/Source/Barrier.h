#pragma once
#include "Actor.h"
#include <Engine/Sprite.h>

class Barrier : public Actor
{
public:
	Barrier();
	~Barrier();

	std::unique_ptr<ASGE::Sprite> Basprite = nullptr;
	float getPosX() const override;
	float getPosY() const override;
	float getWidth() const override;
	float getHeight() const override;
	int damageBarrier();
	int getHealth();
	bool getIsAlive() override;
	

private:
	bool isAlive = true;
	int lifeLeft = 15;

};